import os

for n in range(0, 100):
	os.system('python run.py -b')